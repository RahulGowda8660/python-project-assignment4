total = 0
for score in range(1,51):
    print(score)
    total = total + score
print(f"the total score is:{total}")